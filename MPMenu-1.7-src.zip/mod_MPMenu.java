import java.util.HashMap;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class mod_MPMenu extends BaseMod
{
  private boolean isTakingScreenshot = false;

  public mod_MPMenu()
  {
    String str = "mod.yetanotherx.mpmenu.";
    ModLoader.AddLocalization(str + "gui_mp_title", "Play Multiplayer");

    ModLoader.SetInGameHook(this, true, true);
  }

  public String Version() {
    return "1.6.5";
  }

  public boolean OnTickInGame(Minecraft paramMinecraft)
  {
    if ((paramMinecraft.r == null) && (lq.getInstance() != null))
    {
      if (Keyboard.isKeyDown(Keyboard.getKeyIndex((String)lq.getInstance().getSettings().get("screenshot_key")))) {
        if (!this.isTakingScreenshot) {
          this.isTakingScreenshot = true;

          lq.getInstance().takeServerScreenshot();

          lq.getInstance().b.v.a("Server screenshot taken");
        }
      }
      else
      {
        this.isTakingScreenshot = false;
      }
    }
    return true;
  }
}