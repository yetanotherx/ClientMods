import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiMultiplayerQuickConnect extends da
{
  private lq parent;
  private ro textboxServerLocation;

  public GuiMultiplayerQuickConnect(lq paramlm)
  {
    this.parent = paramlm;
  }

  public void b()
  {
    nh localnd = nh.a();
    Keyboard.enableRepeatEvents(true);
    this.e.clear();
    this.e.add(new ke(0, this.c / 2 - 100, this.d / 4 + 96 + 12, "Connect"));
    this.e.add(new ke(1, this.c / 2 - 100, this.d / 4 + 120 + 12, localnd.a("gui.cancel")));

    ((ke)this.e.get(0)).g = false;

    this.textboxServerLocation = new ro(this, this.g, this.c / 2 - 100, 60, 200, 20, "");
    this.textboxServerLocation.a = true;
    this.textboxServerLocation.a(64);
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    a(this.g, "Connect to a server", this.c / 2, this.d / 4 - 60 + 20, 16777215);
    b(this.g, "Server address: ", this.c / 2 - 100, 47, 10526880);
    this.textboxServerLocation.c();
    super.a(paramInt1, paramInt2, paramFloat);
  }

  public void h()
  {
    Keyboard.enableRepeatEvents(false);
  }

  protected void a(ke paramka)
  {
    if (!paramka.g) {
      return;
    }

    if (paramka.f == 0) {
      GuiMultiplayerServer localGuiMultiplayerServer = new GuiMultiplayerServer();
      lq.tempSelectedServer = this.textboxServerLocation.a();
      localGuiMultiplayerServer.setServerAddress(this.textboxServerLocation.a());
      this.parent.connectToServer(localGuiMultiplayerServer);
    }
    if (paramka.f == 1)
      this.b.a(this.parent);
  }

  protected void a(char paramChar, int paramInt)
  {
    if (this.textboxServerLocation.a) {
      this.textboxServerLocation.a(paramChar, paramInt);
    }
    if (paramChar == '\r') {
      a((ke)this.e.get(0));
    }
    ((ke)this.e.get(0)).g = (this.textboxServerLocation.a().length() > 0);
  }

  protected void a(int paramInt1, int paramInt2, int paramInt3)
  {
    super.a(paramInt1, paramInt2, paramInt3);
    this.textboxServerLocation.a(paramInt1, paramInt2, paramInt3);
  }

  public void a()
  {
    this.textboxServerLocation.b();
  }
}