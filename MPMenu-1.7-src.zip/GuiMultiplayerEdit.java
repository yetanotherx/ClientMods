import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiMultiplayerEdit extends da
{
  private lq parent;
  private ro textboxServerLocation;
  private ro textboxServerName;

  public GuiMultiplayerEdit(lq paramlm)
  {
    this.parent = paramlm;
  }

  public void a()
  {
    this.textboxServerLocation.b();
    this.textboxServerName.b();
  }

  public void b()
  {
    nh localnd = nh.a();
    Keyboard.enableRepeatEvents(true);
    this.e.clear();
    this.e.add(new ke(0, this.c / 2 - 100, this.d / 4 + 96 + 12, "Edit server"));
    this.e.add(new ke(1, this.c / 2 - 100, this.d / 4 + 120 + 12, localnd.a("gui.cancel")));

    this.textboxServerName = new ro(this, this.g, this.c / 2 - 100, 60, 200, 20, this.parent.getSelectedServer().getServerName());
    this.textboxServerName.a = true;
    this.textboxServerName.a(64);

    this.textboxServerLocation = new ro(this, this.g, this.c / 2 - 100, 116, 200, 20, this.parent.getSelectedServer().getServerAddress());
    this.textboxServerLocation.a(64);
  }

  public void h()
  {
    Keyboard.enableRepeatEvents(false);
  }

  protected void a(ke paramka)
  {
    if (!paramka.g) {
      return;
    }

    if (paramka.f == 0) {
      this.parent.changeServer(this.parent.getSelectedServerId(), this.textboxServerName.a(), this.textboxServerLocation.a());
    }
    this.b.a(this.parent);
  }

  protected void a(char paramChar, int paramInt)
  {
    if (this.textboxServerLocation.a) {
      this.textboxServerLocation.a(paramChar, paramInt);
    }
    else if (this.textboxServerName.a) {
      this.textboxServerName.a(paramChar, paramInt);
    }

    if (paramChar == '\r') {
      a((ke)this.e.get(0));
    }
    ((ke)this.e.get(0)).g = (this.textboxServerLocation.a().length() > 0);
  }

  protected void a(int paramInt1, int paramInt2, int paramInt3)
  {
    super.a(paramInt1, paramInt2, paramInt3);
    this.textboxServerLocation.a(paramInt1, paramInt2, paramInt3);
    this.textboxServerName.a(paramInt1, paramInt2, paramInt3);
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    a(this.g, "Edit a server", this.c / 2, this.d / 4 - 60 + 20, 16777215);
    b(this.g, "Server name: ", this.c / 2 - 100, 47, 10526880);
    b(this.g, "Server address: ", this.c / 2 - 100, 104, 10526880);
    this.textboxServerLocation.c();
    this.textboxServerName.c();
    super.a(paramInt1, paramInt2, paramFloat);
  }
}