import java.util.List;
import net.minecraft.client.Minecraft;

public class ex extends da
{
  private String a;
  private String i;

  public ex(String paramString1, String paramString2, Object[] paramArrayOfObject)
  {
    nh localnd = nh.a();
    this.a = localnd.a(paramString1);
    if (paramArrayOfObject != null)
    {
      this.i = localnd.a(paramString2, paramArrayOfObject);
    }
    else
      this.i = localnd.a(paramString2);
  }

  public void a()
  {
  }

  protected void a(char paramChar, int paramInt)
  {
  }

  public void b()
  {
    nh localnd = nh.a();
    this.e.clear();
    this.e.add(new ke(1, this.c / 2 - 100, this.d / 4 + 120 + 12 - 24, "Reconnect"));
    this.e.add(new ke(0, this.c / 2 - 100, this.d / 4 + 120 + 12, "Back to Multiplayer menu"));
  }

  protected void a(ke paramka)
  {
    if (paramka.f == 0)
    {
      this.b.a(lq.getInstance());
    }
    if (paramka.f == 1)
    {
      if (lq.getInstance().getSelectedServerId() == -1) {
        if ((lq.tempSelectedServer != null) && (!lq.tempSelectedServer.equals(""))) {
          GuiMultiplayerServer localGuiMultiplayerServer = new GuiMultiplayerServer();
          localGuiMultiplayerServer.setServerAddress(lq.tempSelectedServer);
          lq.getInstance().connectToServer(localGuiMultiplayerServer);
        }
        else {
          this.b.a(lq.getInstance());
        }
      }
      else
        lq.getInstance().connectToServer(lq.getInstance().getSelectedServer());
    }
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    a(this.g, this.a, this.c / 2, this.d / 2 - 50, 16777215);
    a(this.g, this.i, this.c / 2, this.d / 2 - 10, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }
}