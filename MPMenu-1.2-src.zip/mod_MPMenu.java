import java.util.HashMap;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class mod_MPMenu extends BaseMod
{
  private boolean isTakingScreenshot = false;

  public mod_MPMenu()
  {
    String str = "mod.yetanotherx.mpmenu.";
    ModLoader.AddLocalization(str + "gui_mp_title", "Play Multiplayer");

    ModLoader.SetInGameHook(this, true, true);
  }

  public String Version() {
    return "1.5_01";
  }

  public void OnTickInGame(Minecraft paramMinecraft)
  {
    if (paramMinecraft.r == null)
    {
      if (Keyboard.isKeyDown(Keyboard.getKeyIndex((String)lm.getInstance().getSettings().get("screenshot_key")))) {
        if (!this.isTakingScreenshot) {
          this.isTakingScreenshot = true;

          lm.getInstance().takeServerScreenshot();
        }
      }
      else
      {
        this.isTakingScreenshot = false;
      }
    }
  }
}