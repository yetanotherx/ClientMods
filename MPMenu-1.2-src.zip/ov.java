import java.util.List;
import net.minecraft.client.Minecraft;

public class ov extends cy
{
  private int a;
  private int i;

  public ov()
  {
    this.a = 0;
    this.i = 0;
  }

  public void b()
  {
    this.a = 0;
    this.e.clear();
    int j = -16;
    this.e.add(new ka(1, this.c / 2 - 100, this.d / 4 + 120 + j, "Save and quit to title"));
    if (this.b.l())
    {
      ((ka)this.e.get(0)).e = "Back to Multiplayer menu";
    }
    this.e.add(new ka(4, this.c / 2 - 100, this.d / 4 + 24 + j, "Back to game"));
    this.e.add(new ka(0, this.c / 2 - 100, this.d / 4 + 96 + j, "Options..."));
    this.e.add(new ka(5, this.c / 2 - 100, this.d / 4 + 48 + j, 98, 20, dm.a("gui.achievements")));
    this.e.add(new ka(6, this.c / 2 + 2, this.d / 4 + 48 + j, 98, 20, dm.a("gui.stats")));
  }

  protected void a(ka paramka)
  {
    if (paramka.f == 0)
    {
      this.b.a(new cm(this, this.b.z));
    }
    if (paramka.f == 1)
    {
      this.b.I.a(ji.j, 1);
      if (this.b.l())
      {
        this.b.f.q();
        this.b.a(null);
        this.b.a(lm.getInstance());
      }
      else {
        this.b.a(null);
        this.b.a(new fs());
      }
    }
    if (paramka.f == 4)
    {
      this.b.a(null);
      this.b.g();
    }
    if (paramka.f == 5)
    {
      this.b.a(new xd(this.b.I));
    }
    if (paramka.f == 6)
    {
      this.b.a(new dt(this, this.b.I));
    }
  }

  public void a()
  {
    super.a();
    this.i += 1;
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    int j = !this.b.f.a(this.a++) ? 1 : 0;
    if ((j != 0) || (this.i < 20))
    {
      float f = (this.i % 10 + paramFloat) / 10.0F;
      f = ik.a(f * 3.141593F * 2.0F) * 0.2F + 0.8F;
      int k = (int)(255.0F * f);
      b(this.g, "Saving level..", 8, this.d - 16, k << 16 | k << 8 | k);
    }
    a(this.g, "Game menu", this.c / 2, 40, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }
}