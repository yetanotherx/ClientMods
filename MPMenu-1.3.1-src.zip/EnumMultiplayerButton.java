public enum EnumMultiplayerButton
{
  ADD, 
  EDIT, 
  DELETE, 
  CONNECT, 
  QUICK, 
  CANCEL;
}