import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class lm extends cy
{
  private GuiMultiplayerSlot multiplayerMenuContainer;
  private cy parent;
  private int selectedServer = -1;
  public static String tempSelectedServer;
  private HashMap buttonList = new HashMap();
  private ArrayList servers = new ArrayList();
  private static lm instance;
  private HashMap settings = new HashMap();
  public boolean doRelog = false;
  private HashMap screenshots = new HashMap();

  public lm(cy paramcy)
  {
    this.parent = paramcy;

    this.settings.put("screenshot_key", "F7");

    instance = this;
  }

  public void b()
  {
    this.multiplayerMenuContainer = new GuiMultiplayerSlot(this);
    this.multiplayerMenuContainer.a(this.e, 5, 6);

    initButtons();
    initConfig();
    loadServerList();

    if ((this.doRelog) && (getSelectedServerId() != -1)) {
      this.doRelog = false;
      connectToServer(getSelectedServer());
    }
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    this.multiplayerMenuContainer.a(paramInt1, paramInt2, paramFloat);
    a(this.g, "Play Multiplayer", this.c / 2, 20, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }

  public void initButtons() {
    nd localnd = nd.a();

    this.buttonList.put(EnumMultiplayerButton.ADD, new ka(2, this.c / 2 - 154, this.d - 52, 70, 20, "Add"));
    this.buttonList.put(EnumMultiplayerButton.QUICK, new ka(7, this.c / 2 - 74, this.d - 52, 70, 20, "Quick"));
    this.buttonList.put(EnumMultiplayerButton.EDIT, new ka(3, this.c / 2 - 154, this.d - 28, 70, 20, "Edit"));
    this.buttonList.put(EnumMultiplayerButton.DELETE, new ka(4, this.c / 2 - 74, this.d - 28, 70, 20, "Remove"));
    this.buttonList.put(EnumMultiplayerButton.CONNECT, new ka(0, this.c / 2 + 4, this.d - 52, 150, 20, localnd.a("multiplayer.connect")));
    this.buttonList.put(EnumMultiplayerButton.CANCEL, new ka(1, this.c / 2 + 4, this.d - 28, 150, 20, localnd.a("gui.cancel")));

    for (ka localka : this.buttonList.values()) {
      this.e.add(localka);
    }

    if (getSelectedServerId() == -1)
      setServerSpecificButtonsEnabled(false);
  }

  protected void a(ka paramka)
  {
    if (!paramka.g) {
      return;
    }

    if (paramka.f == 0)
    {
      if (getSelectedServerId() == -1) {
        return;
      }
      connectToServer(getSelectedServer());
    }
    else if (paramka.f == 1) {
      this.b.a(new fs());
    } else if (paramka.f == 2) {
      this.b.a(new GuiMultiplayerAdd(this));
    } else if (paramka.f == 3) {
      this.b.a(new GuiMultiplayerEdit(this));
    } else if (paramka.f == 4) {
      this.b.a(new qo(this, "Are you sure you want to delete this server?", "", "Yes", "No", getSelectedServerId()));
    } else if (paramka.f == 7) {
      this.b.a(new GuiMultiplayerQuickConnect(this));
    }
  }

  public void a(boolean paramBoolean, int paramInt)
  {
    if (paramBoolean) {
      this.servers.remove(paramInt);
      saveServerList();
    }

    this.b.a(this);
  }

  public void createServer(String paramString1, String paramString2)
  {
    for (Object localObject = this.servers.iterator(); ((Iterator)localObject).hasNext(); ) { GuiMultiplayerServer localGuiMultiplayerServer = (GuiMultiplayerServer)((Iterator)localObject).next();
      if (localGuiMultiplayerServer.getServerAddress().equals(paramString2)) {
        return;
      }
    }

    if (!paramString2.equals("")) {
      localObject = new GuiMultiplayerServer();
      ((GuiMultiplayerServer)localObject).setServerAddress(paramString2);
      ((GuiMultiplayerServer)localObject).setServerName(paramString1);

      this.servers.add(localObject);
      saveServerList();
    }

    this.b.a(this);
  }

  public void changeServer(int paramInt, String paramString1, String paramString2) {
    if (!paramString2.equals("")) {
      ((GuiMultiplayerServer)this.servers.get(paramInt)).setServerAddress(paramString2);
      ((GuiMultiplayerServer)this.servers.get(paramInt)).setServerName(paramString1);
      saveServerList();
    }

    this.b.a(this);
  }

  public int selectServer(int paramInt) {
    this.selectedServer = paramInt;
    return this.selectedServer;
  }

  public ArrayList getServerList() {
    return this.servers;
  }

  public void saveServerList() {
    FileOutputStream localFileOutputStream = null;
    ObjectOutputStream localObjectOutputStream = null;
    try
    {
      localFileOutputStream = new FileOutputStream(new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "server_list.dat"));
      localObjectOutputStream = new ObjectOutputStream(localFileOutputStream);
      localObjectOutputStream.writeObject(this.servers);
      localObjectOutputStream.close();
    } catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  public void loadServerList()
  {
    FileInputStream localFileInputStream = null;
    ObjectInputStream localObjectInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "server_list.dat"));
      localObjectInputStream = new ObjectInputStream(localFileInputStream);
      this.servers = ((ArrayList)localObjectInputStream.readObject());

      if (this.servers == null) {
        this.servers = new ArrayList();
      }
      localObjectInputStream.close();
    } catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  private int stringToInt(String paramString, int paramInt)
  {
    try {
      return Integer.parseInt(paramString.trim()); } catch (Exception localException) {
    }
    return paramInt;
  }

  public int getSelectedServerId()
  {
    return this.selectedServer;
  }

  public GuiMultiplayerServer getSelectedServer() {
    return (GuiMultiplayerServer)this.servers.get(this.selectedServer);
  }

  public File getModLibPath() {
    return Minecraft.b();
  }

  public int getTexture(File paramFile)
  {
    Integer localInteger = (Integer)this.screenshots.get(paramFile.getAbsolutePath());
    if (localInteger != null) {
      return localInteger.intValue();
    }

    IntBuffer localIntBuffer = gc.d(1);
    try {
      localIntBuffer.clear();
      gc.a(localIntBuffer);
      int i = localIntBuffer.get(0);

      this.parent.b.p.a(ImageIO.read(paramFile), i);

      this.screenshots.put(paramFile.getAbsolutePath(), Integer.valueOf(i));

      return i;
    } catch (IOException localIOException) {
      localIOException.printStackTrace();
    }

    return this.parent.b.p.b("this does not and will never exist");
  }

  public void connectToServer(GuiMultiplayerServer paramGuiMultiplayerServer)
  {
    this.b.z.C = paramGuiMultiplayerServer.getServerAddress().replaceAll(":", "_");
    this.b.z.b();

    String[] arrayOfString = paramGuiMultiplayerServer.getServerAddress().split(":");

    this.b.a(new vp(this.b, arrayOfString[0], arrayOfString.length <= 1 ? 25565 : stringToInt(arrayOfString[1], 25565)));
  }

  public void initConfig() {
    new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu").mkdirs();
    File localFile1 = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "server_list.dat");
    if (!localFile1.exists()) {
      saveServerList();
    }

    new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu").mkdirs();
    File localFile2 = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "settings.cfg");
    if (!localFile2.exists()) {
      savePreferences();
    }
    loadPreferences();
  }

  public void takeServerScreenshot()
  {
    if ((getSelectedServerId() == -1) || (this.b.r != null)) {
      return;
    }

    ByteBuffer localByteBuffer = null;
    byte[] arrayOfByte = null;
    int[] arrayOfInt = null;

    int i = instance.b.d;
    int j = instance.b.e;
    try
    {
      File localFile1 = new File(Minecraft.b(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "screenshots");
      localFile1.mkdirs();

      if ((localByteBuffer == null) || (localByteBuffer.capacity() < i * j)) {
        localByteBuffer = BufferUtils.createByteBuffer(i * j * 3);
      }

      if ((arrayOfInt == null) || (arrayOfInt.length < i * j * 3)) {
        arrayOfByte = new byte[i * j * 3];
        arrayOfInt = new int[i * j];
      }

      GL11.glPixelStorei(3333, 1);
      GL11.glPixelStorei(3317, 1);
      localByteBuffer.clear();

      GL11.glReadPixels(0, 0, i, j, 6407, 5121, localByteBuffer);
      localByteBuffer.clear();

      String str = getSelectedServer().getServerAddress().replaceAll(":", "_");

      File localFile2 = new File(localFile1, str + ".png");
      if (localFile2.exists()) {
        localFile2.delete();
      }

      localByteBuffer.get(arrayOfByte);
      for (int k = 0; k < i; k++) {
        for (int m = 0; m < j; m++) {
          int n = k + (j - m - 1) * i;
          int i1 = arrayOfByte[(n * 3 + 0)] & 0xFF;
          int i2 = arrayOfByte[(n * 3 + 1)] & 0xFF;
          int i3 = arrayOfByte[(n * 3 + 2)] & 0xFF;
          int i4 = 0xFF000000 | i1 << 16 | i2 << 8 | i3;
          arrayOfInt[(k + m * i)] = i4;
        }

      }

      BufferedImage localBufferedImage1 = new BufferedImage(i, j, 1);
      localBufferedImage1.setRGB(0, 0, i, j, arrayOfInt, 0, i);

      BufferedImage localBufferedImage2 = new BufferedImage(128, 72, 1);
      Graphics2D localGraphics2D = localBufferedImage2.createGraphics();
      localGraphics2D.drawImage(localBufferedImage1, 0, 0, 128, 72, null);
      localGraphics2D.dispose();

      ImageIO.write(localBufferedImage2, "png", localFile2);
    }
    catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  public HashMap getButtonList() {
    return this.buttonList;
  }

  public static lm getInstance() {
    return instance;
  }

  public void setServerSpecificButtonsEnabled(boolean paramBoolean)
  {
    if (!this.buttonList.containsKey(EnumMultiplayerButton.CONNECT)) {
      return;
    }

    ((ka)this.buttonList.get(EnumMultiplayerButton.CONNECT)).g = paramBoolean;
    ((ka)this.buttonList.get(EnumMultiplayerButton.EDIT)).g = paramBoolean;
    ((ka)this.buttonList.get(EnumMultiplayerButton.DELETE)).g = paramBoolean;
  }

  private void loadPreferences()
  {
    try {
      File localFile = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "settings.cfg");
      if (localFile.exists()) {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(localFile));
        String str = "";
        while ((str = localBufferedReader.readLine()) != null) {
          String[] arrayOfString = str.split(":", 2);
          if ((arrayOfString.length > 1) && (this.settings.containsKey(arrayOfString[0]))) {
            this.settings.put(arrayOfString[0], arrayOfString[1]);
          }
        }
        localBufferedReader.close();
      }
    } catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  private void savePreferences() {
    try {
      File localFile = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "settings.cfg");
      PrintWriter localPrintWriter = new PrintWriter(new FileWriter(localFile));
      for (String str : this.settings.keySet()) {
        localPrintWriter.println(str + ":" + (String)this.settings.get(str));
      }
      localPrintWriter.close();
    } catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  public HashMap getSettings() {
    return this.settings;
  }

  public HashMap getScreenshots() {
    return this.screenshots;
  }
}