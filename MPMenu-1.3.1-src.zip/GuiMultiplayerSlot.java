import java.io.File;
import java.util.ArrayList;
import org.lwjgl.opengl.GL11;

public class GuiMultiplayerSlot extends lc
{
  private final lm parent;
  private boolean hasRendered = false;

  public GuiMultiplayerSlot(lm paramlm) {
    super(paramlm.b, paramlm.c, paramlm.d, 32, paramlm.d - 64, 36);
    this.parent = paramlm;
  }

  protected int a() {
    return this.parent.getServerList().size();
  }

  protected void a(int paramInt, boolean paramBoolean)
  {
    this.parent.selectServer(paramInt);

    boolean bool = (this.parent.getSelectedServerId() >= 0) && (this.parent.getSelectedServerId() < a());

    this.parent.setServerSpecificButtonsEnabled(bool);

    if ((paramBoolean) && (bool))
      this.parent.connectToServer(this.parent.getSelectedServer());
  }

  protected boolean a_(int paramInt)
  {
    return this.parent.getSelectedServerId() == paramInt;
  }

  protected int b()
  {
    return this.parent.getServerList().size() * 36;
  }

  protected void c() {
    this.parent.i();
  }

  protected void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ns paramns)
  {
    String str1 = ((GuiMultiplayerServer)this.parent.getServerList().get(paramInt1)).getServerName();
    String str2 = ((GuiMultiplayerServer)this.parent.getServerList().get(paramInt1)).getServerAddress();
    String str3 = str2.replaceAll(":", "_") + ".png";

    str2 = str2.replaceAll("_", ":");

    if (str1.equals("")) {
      str1 = str2.toString();
      str2 = "";
    }
    try
    {
      File localFile = new File(this.parent.getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "screenshots" + File.separator + str3);

      if (localFile.exists()) {
        GL11.glBindTexture(3553, this.parent.getTexture(localFile));
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

        paramns.b();
        paramns.b(16777215);
        paramns.a(paramInt2, paramInt3 + paramInt4, 0.0D, 0.0D, 1.0D);
        paramns.a(paramInt2 + 48, paramInt3 + paramInt4, 0.0D, 1.0D, 1.0D);
        paramns.a(paramInt2 + 48, paramInt3, 0.0D, 1.0D, 0.0D);
        paramns.a(paramInt2, paramInt3, 0.0D, 0.0D, 0.0D);
        paramns.a();

        this.parent.b(this.parent.g, str1, paramInt2 + 52, paramInt3 + 1, 16777215);
        this.parent.b(this.parent.g, str2, paramInt2 + 52, paramInt3 + 12, 8421504);
      } else {
        this.parent.b(this.parent.g, str1, paramInt2 + 2, paramInt3 + 1, 16777215);
        this.parent.b(this.parent.g, str2, paramInt2 + 2, paramInt3 + 12, 8421504);
      }
    }
    catch (Exception localException) {
      localException.printStackTrace();
      this.parent.b(this.parent.g, str1, paramInt2 + 2, paramInt3 + 1, 16777215);
      this.parent.b(this.parent.g, str2, paramInt2 + 2, paramInt3 + 12, 8421504);
    }
  }
}