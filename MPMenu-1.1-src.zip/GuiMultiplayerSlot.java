import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import org.lwjgl.opengl.GL11;

public class GuiMultiplayerSlot extends kk
{
  private final ku parent;

  public GuiMultiplayerSlot(ku paramku)
  {
    super(paramku.b, paramku.c, paramku.d, 32, paramku.d - 64, 36);
    this.parent = paramku;
  }

  protected int a() {
    return this.parent.getServerList().size();
  }

  protected void a(int paramInt, boolean paramBoolean)
  {
    this.parent.selectServer(paramInt);

    boolean bool = (this.parent.getSelectedServer() >= 0) && (this.parent.getSelectedServer() < a());

    this.parent.getButtonConnect().g = bool;
    this.parent.getButtonEdit().g = bool;
    this.parent.getButtonDelete().g = bool;

    if ((paramBoolean) && (bool)) {
      String str = ((String[])this.parent.getServerList().get(this.parent.getSelectedServer()))[0];
      this.parent.connectToServer(str);
    }
  }

  protected boolean a_(int paramInt)
  {
    return this.parent.getSelectedServer() == paramInt;
  }

  protected int b()
  {
    return this.parent.getServerList().size() * 36;
  }

  protected void c() {
    this.parent.i();
  }

  protected void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, na paramna)
  {
    String str1 = ((String[])this.parent.getServerList().get(paramInt1))[0];
    String str2 = "Last connect: ";
    Object localObject1;
    Object localObject2;
    if (!((String[])this.parent.getServerList().get(paramInt1))[1].equals("0")) {
      localObject1 = Calendar.getInstance();
      localObject2 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
      ((Calendar)localObject1).setTimeInMillis(Long.parseLong(((String[])this.parent.getServerList().get(paramInt1))[1]));

      str2 = str2 + ((SimpleDateFormat)localObject2).format(((Calendar)localObject1).getTime());
    } else {
      str2 = str2 + "Never";
    }

    str1 = str1.replaceAll("_", ":");
    try
    {
      if (((String[])this.parent.getServerList().get(paramInt1)).length > 2) {
        localObject1 = this.parent.getModLibPath();
        localObject2 = new File((File)localObject1, "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "screenshots");
        ((File)localObject2).mkdirs();
        localObject2 = new File((File)localObject2, ((String[])this.parent.getServerList().get(paramInt1))[2] + ".png").getAbsoluteFile();

        GL11.glBindTexture(3553, this.parent.getTexture(((String[])this.parent.getServerList().get(paramInt1))[0], (File)localObject2));

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        paramna.b();
        paramna.b(16777215);
        paramna.a(paramInt2, paramInt3 + paramInt4, 0.0D, 0.0D, 1.0D);
        paramna.a(paramInt2 + 48, paramInt3 + paramInt4, 0.0D, 1.0D, 1.0D);
        paramna.a(paramInt2 + 48, paramInt3, 0.0D, 1.0D, 0.0D);
        paramna.a(paramInt2, paramInt3, 0.0D, 0.0D, 0.0D);
        paramna.a();

        this.parent.b(this.parent.g, str1, paramInt2 + 52, paramInt3 + 1, 16777215);
        this.parent.b(this.parent.g, str2, paramInt2 + 52, paramInt3 + 12, 8421504);
      } else {
        this.parent.b(this.parent.g, str1, paramInt2 + 2, paramInt3 + 1, 16777215);
        this.parent.b(this.parent.g, str2, paramInt2 + 2, paramInt3 + 12, 8421504);
      }
    }
    catch (Exception localException) {
      localException.printStackTrace();
      this.parent.b(this.parent.g, str1, paramInt2 + 2, paramInt3 + 1, 16777215);
      this.parent.b(this.parent.g, str2, paramInt2 + 2, paramInt3 + 12, 8421504);
    }
  }
}