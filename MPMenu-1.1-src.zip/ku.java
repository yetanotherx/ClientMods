import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.IntBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;

public class ku extends cs
{
  private GuiMultiplayerSlot multiplayerMenuContainer;
  private final DateFormat dateFormatter = new SimpleDateFormat();
  protected cs parent;
  protected String screenTitle = "Play Multiplayer";
  private boolean selected = false;
  private int selectedServer = -1;
  private ArrayList serverList = new ArrayList();
  private jk buttonEdit;
  private jk buttonAdd;
  private jk buttonDelete;
  private jk buttonConnect;
  private jk buttonQuick;
  private jk buttonCancel;
  private static String lastServer;
  public static ku instance;

  public ku(cs paramcs)
  {
    this.parent = paramcs;
    instance = this;
  }

  public void a()
  {
    this.screenTitle = "Play Multiplayer";

    this.multiplayerMenuContainer = new GuiMultiplayerSlot(this);
    this.multiplayerMenuContainer.a(this.e, 5, 6);

    setButtons();

    initConfig();

    loadServerList();
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    this.multiplayerMenuContainer.a(paramInt1, paramInt2, paramFloat);
    a(this.g, this.screenTitle, this.c / 2, 20, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }

  public void setButtons() {
    ml localml = ml.a();

    this.buttonAdd = new jk(2, this.c / 2 - 154, this.d - 52, 70, 20, "Add");
    this.buttonQuick = new jk(7, this.c / 2 - 74, this.d - 52, 70, 20, "Quick");
    this.buttonEdit = new jk(3, this.c / 2 - 154, this.d - 28, 70, 20, "Edit");
    this.buttonDelete = new jk(4, this.c / 2 - 74, this.d - 28, 70, 20, "Remove");
    this.buttonConnect = new jk(0, this.c / 2 + 4, this.d - 52, 150, 20, localml.a("multiplayer.connect"));
    this.buttonCancel = new jk(1, this.c / 2 + 4, this.d - 28, 150, 20, localml.a("gui.cancel"));

    this.e.add(this.buttonAdd);
    this.e.add(this.buttonEdit);
    this.e.add(this.buttonQuick);
    this.e.add(this.buttonDelete);
    this.e.add(this.buttonConnect);
    this.e.add(this.buttonCancel);

    this.buttonConnect.g = false;
    this.buttonEdit.g = false;
    this.buttonDelete.g = false;
  }

  protected void a(jk paramjk)
  {
    if (!paramjk.g)
      return;
    Object localObject;
    if (paramjk.f == 0)
    {
      if (getSelectedServer() == -1) {
        return;
      }

      localObject = ((String[])getServerList().get(getSelectedServer()))[0];

      connectToServer((String)localObject);
    } else if (paramjk.f == 1) {
      this.b.a(new fh());
    } else if (paramjk.f == 2) {
      this.b.a(new GuiMultiplayerAdd(this));
    } else if (paramjk.f == 3) {
      this.b.a(new GuiMultiplayerEdit(this, getSelectedServer()));
    } else if (paramjk.f == 4)
    {
      if (getSelectedServer() == -1) {
        return;
      }

      localObject = new pt(this, "Are you sure you want to delete this server?", "", "Yes", "No", getSelectedServer());
      this.b.a((cs)localObject);
    } else if (paramjk.f == 7) {
      this.b.a(new GuiMultiplayerQuickConnect(this));
    }
  }

  public void a(boolean paramBoolean, int paramInt)
  {
    if (paramBoolean)
    {
      this.serverList.remove(paramInt);
      saveServerList();
    }

    this.b.a(this);
  }

  public void createServer(String paramString)
  {
    for (String[] arrayOfString : this.serverList) {
      if (arrayOfString[0].equals(paramString)) return;
    }

    if (!paramString.equals("")) {
      this.serverList.add(new String[] { paramString, "0" });
      saveServerList();
    }

    this.b.a(this);
  }

  public void changeServer(int paramInt, String paramString)
  {
    if (!paramString.equals("")) {
      ((String[])this.serverList.get(paramInt))[0] = paramString;
      saveServerList();
    }

    this.b.a(this);
  }

  public int selectServer(int paramInt) {
    this.selectedServer = paramInt;
    return this.selectedServer;
  }

  public ArrayList getServerList() {
    return this.serverList;
  }

  public void saveServerList() {
    FileOutputStream localFileOutputStream = null;
    ObjectOutputStream localObjectOutputStream = null;
    try
    {
      localFileOutputStream = new FileOutputStream(new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "servers.dat"));
      localObjectOutputStream = new ObjectOutputStream(localFileOutputStream);
      localObjectOutputStream.writeObject(this.serverList);
      localObjectOutputStream.close();
    }
    catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  public void loadServerList() {
    ArrayList localArrayList = new ArrayList();

    FileInputStream localFileInputStream = null;
    ObjectInputStream localObjectInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "servers.dat"));
      localObjectInputStream = new ObjectInputStream(localFileInputStream);
      this.serverList = ((ArrayList)localObjectInputStream.readObject());

      if (this.serverList == null) {
        this.serverList = new ArrayList();
      }
      localObjectInputStream.close();
    }
    catch (Exception localException) {
      localException.printStackTrace();
    }
  }

  private int stringToInt(String paramString, int paramInt)
  {
    try {
      return Integer.parseInt(paramString.trim()); } catch (Exception localException) {
    }
    return paramInt;
  }

  public jk getButtonAdd()
  {
    return this.buttonAdd;
  }

  public jk getButtonCancel() {
    return this.buttonCancel;
  }

  public jk getButtonConnect() {
    return this.buttonConnect;
  }

  public jk getButtonDelete() {
    return this.buttonDelete;
  }

  public jk getButtonEdit() {
    return this.buttonEdit;
  }

  public jk getButtonQuick() {
    return this.buttonQuick;
  }

  public int getSelectedServer() {
    return this.selectedServer;
  }

  public static String getLastServer() {
    return lastServer;
  }

  public File getModLibPath() {
    return Minecraft.b();
  }

  public int getTexture(String paramString, File paramFile)
  {
    IntBuffer localIntBuffer = ft.c(1);
    try {
      localIntBuffer.clear();
      ft.a(localIntBuffer);
      int i = localIntBuffer.get(0);

      this.parent.b.o.a(ImageIO.read(paramFile), i);
      return i;
    } catch (IOException localIOException) {
      localIOException.printStackTrace();
    }

    return this.parent.b.o.a("this does not and will never exist");
  }

  public void connectToServer(String paramString)
  {
    this.b.y.C = paramString.replaceAll(":", "_");
    this.b.y.b();
    lastServer = paramString;

    String[] arrayOfString1 = paramString.split(":");

    for (String[] arrayOfString2 : this.serverList) {
      if (arrayOfString2[0].equals(paramString)) {
        arrayOfString2[1] = String.valueOf(System.currentTimeMillis());
        saveServerList();
        break;
      }
    }

    this.b.a(new uq(this.b, arrayOfString1[0], arrayOfString1.length <= 1 ? 25565 : stringToInt(arrayOfString1[1], 25565)));
  }

  public void initConfig() {
    new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu").mkdirs();
    File localFile = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "servers.dat");
    if (!localFile.exists())
      saveServerList();
  }
}