import java.util.List;
import net.minecraft.client.Minecraft;

public class en extends cs
{
  private String a;
  private String i;

  public en(String paramString1, String paramString2, Object[] paramArrayOfObject)
  {
    ml localml = ml.a();
    this.a = localml.a(paramString1);
    if (paramArrayOfObject != null)
    {
      this.i = localml.a(paramString2, paramArrayOfObject);
    }
    else
      this.i = localml.a(paramString2);
  }

  public void g()
  {
  }

  protected void a(char paramChar, int paramInt)
  {
  }

  public void a()
  {
    ml localml = ml.a();
    this.e.clear();
    this.e.add(new jk(1, this.c / 2 - 100, this.d / 4 + 120 + 12 - 24, "Reconnect"));
    this.e.add(new jk(0, this.c / 2 - 100, this.d / 4 + 120 + 12, "Back to Multiplayer menu"));
  }

  protected void a(jk paramjk)
  {
    if (paramjk.f == 0)
    {
      this.b.a(ku.instance);
    }
    if (paramjk.f == 1)
    {
      ku.instance.connectToServer(ku.getLastServer());
    }
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    a(this.g, this.a, this.c / 2, this.d / 2 - 50, 16777215);
    a(this.g, this.i, this.c / 2, this.d / 2 - 10, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }
}