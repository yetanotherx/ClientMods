import java.util.List;
import net.minecraft.client.Minecraft;

public class oa extends cs
{
  private int a;
  private int i;

  public oa()
  {
    this.a = 0;
    this.i = 0;
  }

  public void a()
  {
    this.a = 0;
    this.e.clear();
    int j = -16;
    this.e.add(new jk(1, this.c / 2 - 100, this.d / 4 + 120 + j, "Save and quit to title"));
    if (this.b.k())
    {
      ((jk)this.e.get(0)).e = "Back to Multiplayer menu";
    }
    this.e.add(new jk(4, this.c / 2 - 100, this.d / 4 + 24 + j, "Back to game"));
    this.e.add(new jk(0, this.c / 2 - 100, this.d / 4 + 96 + j, "Options..."));
    this.e.add(new jk(5, this.c / 2 - 100, this.d / 4 + 48 + j, 98, 20, dg.a("gui.achievements")));
    this.e.add(new jk(6, this.c / 2 + 2, this.d / 4 + 48 + j, 98, 20, dg.a("gui.stats")));
  }

  protected void a(jk paramjk)
  {
    if (paramjk.f == 0)
    {
      this.b.a(new ch(this, this.b.y));
    }
    if (paramjk.f == 1)
    {
      this.b.G.a(is.j, 1);
      if (this.b.k())
      {
        this.b.e.q();
        this.b.a(null);
        this.b.a(ku.instance);
      }
      else {
        this.b.a(null);
        this.b.a(new fh());
      }
    }
    if (paramjk.f == 4)
    {
      this.b.a(null);
      this.b.f();
    }
    if (paramjk.f == 5)
    {
      this.b.a(new wc(this.b.G));
    }
    if (paramjk.f == 6)
    {
      this.b.a(new dn(this, this.b.G));
    }
  }

  public void g()
  {
    super.g();
    this.i += 1;
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    int j = !this.b.e.a(this.a++) ? 1 : 0;
    if ((j != 0) || (this.i < 20))
    {
      float f = (this.i % 10 + paramFloat) / 10.0F;
      f = hy.a(f * 3.141593F * 2.0F) * 0.2F + 0.8F;
      int k = (int)(255.0F * f);
      b(this.g, "Saving level..", 8, this.d - 16, k << 16 | k << 8 | k);
    }
    a(this.g, "Game menu", this.c / 2, 40, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }
}