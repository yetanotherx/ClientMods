import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiMultiplayerEdit extends cs
{
  private ku parent;
  private qn serverAddressTextBox;
  private final int server_id;

  public GuiMultiplayerEdit(ku paramku, int paramInt)
  {
    this.parent = paramku;
    this.server_id = paramInt;
  }

  public void g()
  {
    this.serverAddressTextBox.b();
  }

  public void a()
  {
    ml localml = ml.a();
    Keyboard.enableRepeatEvents(true);
    this.e.clear();
    this.e.add(new jk(0, this.c / 2 - 100, this.d / 4 + 96 + 12, "OK"));
    this.e.add(new jk(1, this.c / 2 - 100, this.d / 4 + 120 + 12, localml.a("gui.cancel")));

    this.serverAddressTextBox = new qn(this, this.g, this.c / 2 - 100, 60, 200, 20, ((String[])this.parent.getServerList().get(this.server_id))[0]);
    this.serverAddressTextBox.a = true;
    this.serverAddressTextBox.a(64);
  }

  public void h()
  {
    Keyboard.enableRepeatEvents(false);
  }

  protected void a(jk paramjk)
  {
    if (!paramjk.g)
    {
      return;
    }

    if (paramjk.f == 0)
    {
      this.parent.changeServer(this.server_id, this.serverAddressTextBox.a().trim());
    }
    this.b.a(this.parent);
  }

  protected void a(char paramChar, int paramInt)
  {
    this.serverAddressTextBox.a(paramChar, paramInt);
    ((jk)this.e.get(0)).g = (this.serverAddressTextBox.a().trim().length() > 0);
    if (paramChar == '\r')
    {
      a((jk)this.e.get(0));
    }
  }

  protected void a(int paramInt1, int paramInt2, int paramInt3)
  {
    super.a(paramInt1, paramInt2, paramInt3);
    this.serverAddressTextBox.a(paramInt1, paramInt2, paramInt3);
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    ml localml = ml.a();
    i();
    a(this.g, "Edit a server", this.c / 2, this.d / 4 - 60 + 20, 16777215);
    b(this.g, "Server location: ", this.c / 2 - 100, 47, 10526880);
    this.serverAddressTextBox.c();
    super.a(paramInt1, paramInt2, paramFloat);
  }
}