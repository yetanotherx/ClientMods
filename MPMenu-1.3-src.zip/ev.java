import java.util.List;
import net.minecraft.client.Minecraft;

public class ev extends cy
{
  private String a;
  private String i;

  public ev(String paramString1, String paramString2, Object[] paramArrayOfObject)
  {
    nd localnd = nd.a();
    this.a = localnd.a(paramString1);
    if (paramArrayOfObject != null)
    {
      this.i = localnd.a(paramString2, paramArrayOfObject);
    }
    else
      this.i = localnd.a(paramString2);
  }

  public void a()
  {
  }

  protected void a(char paramChar, int paramInt)
  {
  }

  public void b()
  {
    nd localnd = nd.a();
    this.e.clear();
    this.e.add(new ka(1, this.c / 2 - 100, this.d / 4 + 120 + 12 - 24, "Reconnect"));
    this.e.add(new ka(0, this.c / 2 - 100, this.d / 4 + 120 + 12, "Back to Multiplayer menu"));
  }

  protected void a(ka paramka)
  {
    if (paramka.f == 0)
    {
      this.b.a(lm.getInstance());
    }
    if (paramka.f == 1)
    {
      if (lm.getInstance().getSelectedServerId() == -1) {
        if ((lm.tempSelectedServer != null) && (!lm.tempSelectedServer.equals(""))) {
          GuiMultiplayerServer localGuiMultiplayerServer = new GuiMultiplayerServer();
          localGuiMultiplayerServer.setServerAddress(lm.tempSelectedServer);
          lm.getInstance().connectToServer(localGuiMultiplayerServer);
        }
        else {
          this.b.a(lm.getInstance());
        }
      }
      else
        lm.getInstance().connectToServer(lm.getInstance().getSelectedServer());
    }
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();
    a(this.g, this.a, this.c / 2, this.d / 2 - 50, 16777215);
    a(this.g, this.i, this.c / 2, this.d / 2 - 10, 16777215);
    super.a(paramInt1, paramInt2, paramFloat);
  }
}