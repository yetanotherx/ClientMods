import java.io.Serializable;

public class GuiMultiplayerServer
  implements Serializable
{
  private String server_name = "";
  private String server_address = "";

  public String getServerAddress() {
    return this.server_address;
  }

  public void setServerAddress(String paramString) {
    this.server_address = paramString;
  }

  public String getServerName() {
    return this.server_name;
  }

  public void setServerName(String paramString) {
    this.server_name = paramString;
  }
}