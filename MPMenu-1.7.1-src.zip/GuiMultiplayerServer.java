import java.io.Serializable;

public class GuiMultiplayerServer
  implements Serializable
{
  private String server_name;
  private String server_address;

  public GuiMultiplayerServer()
  {
    this.server_name = "";
    this.server_address = "";
  }

  public String getServerAddress()
  {
    return this.server_address;
  }

  public void setServerAddress(String s)
  {
    this.server_address = s;
  }

  public String getServerName()
  {
    return this.server_name;
  }

  public void setServerName(String s)
  {
    this.server_name = s;
  }
}