import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class lq extends da
{
  private GuiMultiplayerSlot multiplayerMenuContainer;
  private da parent;
  private int selectedServer;
  public static String tempSelectedServer;
  private HashMap buttonList;
  private ArrayList servers;
  private static lq instance;
  private HashMap settings;
  public boolean doRelog;
  private HashMap screenshots;

  public lq(da guiscreen)
  {
    this.selectedServer = -1;
    this.buttonList = new HashMap();
    this.servers = new ArrayList();
    this.settings = new HashMap();
    this.doRelog = false;
    this.screenshots = new HashMap();
    this.parent = guiscreen;
    this.settings.put("screenshot_key", "F7");
    instance = this;
  }

  public void b()
  {
    this.multiplayerMenuContainer = new GuiMultiplayerSlot(this);
    this.multiplayerMenuContainer.a(this.e, 5, 6);
    initButtons();
    initConfig();
    loadServerList();
    if ((this.doRelog) && (getSelectedServerId() != -1))
    {
      this.doRelog = false;
      connectToServer(getSelectedServer());
    }
  }

  public void a(int i, int j, float f)
  {
    this.multiplayerMenuContainer.a(i, j, f);
    a(this.g, "Play Multiplayer", this.c / 2, 20, 16777215);
    super.a(i, j, f);
  }

  public void initButtons()
  {
    nh stringtranslate = nh.a();
    this.buttonList.put(EnumMultiplayerButton.ADD, new ke(2, this.c / 2 - 154, this.d - 52, 70, 20, "Add"));
    this.buttonList.put(EnumMultiplayerButton.QUICK, new ke(7, this.c / 2 - 74, this.d - 52, 70, 20, "Quick"));
    this.buttonList.put(EnumMultiplayerButton.EDIT, new ke(3, this.c / 2 - 154, this.d - 28, 70, 20, "Edit"));
    this.buttonList.put(EnumMultiplayerButton.DELETE, new ke(4, this.c / 2 - 74, this.d - 28, 70, 20, "Remove"));
    this.buttonList.put(EnumMultiplayerButton.CONNECT, new ke(0, this.c / 2 + 4, this.d - 52, 150, 20, stringtranslate.a("multiplayer.connect")));
    this.buttonList.put(EnumMultiplayerButton.CANCEL, new ke(1, this.c / 2 + 4, this.d - 28, 150, 20, stringtranslate.a("gui.cancel")));
    ke guibutton;
    for (Iterator iterator = this.buttonList.values().iterator(); iterator.hasNext(); this.e.add(guibutton))
    {
      guibutton = (ke)iterator.next();
    }

    if (getSelectedServerId() == -1)
    {
      setServerSpecificButtonsEnabled(false);
    }
  }

  protected void a(ke guibutton)
  {
    if (!guibutton.g)
    {
      return;
    }
    if (guibutton.f == 0)
    {
      if (getSelectedServerId() == -1)
      {
        return;
      }
      connectToServer(getSelectedServer());
    }
    else if (guibutton.f == 1)
    {
      this.b.a(new fu());
    }
    else if (guibutton.f == 2)
    {
      this.b.a(new GuiMultiplayerAdd(this));
    }
    else if (guibutton.f == 3)
    {
      this.b.a(new GuiMultiplayerEdit(this));
    }
    else if (guibutton.f == 4)
    {
      this.b.a(new qt(this, "Are you sure you want to delete this server?", "", "Yes", "No", getSelectedServerId()));
    }
    else if (guibutton.f == 7)
    {
      this.b.a(new GuiMultiplayerQuickConnect(this));
    }
  }

  public void a(boolean flag, int i)
  {
    if (flag)
    {
      this.servers.remove(i);
      saveServerList();
    }
    this.b.a(this);
  }

  public void createServer(String s, String s1)
  {
    for (Iterator iterator = this.servers.iterator(); iterator.hasNext(); )
    {
      GuiMultiplayerServer guimultiplayerserver1 = (GuiMultiplayerServer)iterator.next();
      if (guimultiplayerserver1.getServerAddress().equals(s1))
      {
        return;
      }
    }

    if (!s1.equals(""))
    {
      GuiMultiplayerServer guimultiplayerserver = new GuiMultiplayerServer();
      guimultiplayerserver.setServerAddress(s1);
      guimultiplayerserver.setServerName(s);
      this.servers.add(guimultiplayerserver);
      saveServerList();
    }
    this.b.a(this);
  }

  public void changeServer(int i, String s, String s1)
  {
    if (!s1.equals(""))
    {
      ((GuiMultiplayerServer)this.servers.get(i)).setServerAddress(s1);
      ((GuiMultiplayerServer)this.servers.get(i)).setServerName(s);
      saveServerList();
    }
    this.b.a(this);
  }

  public int selectServer(int i)
  {
    this.selectedServer = i;
    return this.selectedServer;
  }

  public ArrayList getServerList()
  {
    return this.servers;
  }

  public void saveServerList()
  {
    Object obj = null;
    Object obj1 = null;
    try
    {
      FileOutputStream fileoutputstream = new FileOutputStream(new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "server_list.dat"));
      ObjectOutputStream objectoutputstream = new ObjectOutputStream(fileoutputstream);
      objectoutputstream.writeObject(this.servers);
      objectoutputstream.close();
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }

  public void loadServerList()
  {
    Object obj = null;
    Object obj1 = null;
    try
    {
      FileInputStream fileinputstream = new FileInputStream(new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "server_list.dat"));
      ObjectInputStream objectinputstream = new ObjectInputStream(fileinputstream);
      this.servers = ((ArrayList)objectinputstream.readObject());
      if (this.servers == null)
      {
        this.servers = new ArrayList();
      }
      objectinputstream.close();
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }

  private int stringToInt(String s, int i)
  {
    try
    {
      return Integer.parseInt(s.trim());
    }
    catch (Exception exception) {
    }
    return i;
  }

  public int getSelectedServerId()
  {
    return this.selectedServer;
  }

  public GuiMultiplayerServer getSelectedServer()
  {
    return (GuiMultiplayerServer)this.servers.get(this.selectedServer);
  }

  public File getModLibPath()
  {
    return Minecraft.b();
  }

  public int getTexture(File file)
  {
    Integer integer = (Integer)this.screenshots.get(file.getAbsolutePath());
    if (integer != null)
    {
      return integer.intValue();
    }
    IntBuffer intbuffer = ge.d(1);
    try
    {
      intbuffer.clear();
      ge.a(intbuffer);
      int i = intbuffer.get(0);
      this.parent.b.p.a(ImageIO.read(file), i);
      this.screenshots.put(file.getAbsolutePath(), Integer.valueOf(i));
      return i;
    }
    catch (IOException ioexception)
    {
      ioexception.printStackTrace();
    }
    return this.parent.b.p.b("this does not and will never exist");
  }

  public void connectToServer(GuiMultiplayerServer guimultiplayerserver)
  {
    this.b.z.C = guimultiplayerserver.getServerAddress().replaceAll(":", "_");
    this.b.z.b();
    String[] as = guimultiplayerserver.getServerAddress().split(":");
    this.b.a(new vx(this.b, as[0], as.length > 1 ? stringToInt(as[1], 25565) : 25565));
  }

  public void takeServerScreenshot()
  {
    if ((getSelectedServerId() == -1) || (this.b.r != null))
    {
      return;
    }
    ByteBuffer bytebuffer = null;
    byte[] abyte0 = null;
    int[] ai = null;
    int i = instance.b.d;
    int j = instance.b.e;
    try
    {
      File file = new File(Minecraft.b(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "screenshots");
      file.mkdirs();
      if ((bytebuffer == null) || (bytebuffer.capacity() < i * j))
      {
        bytebuffer = BufferUtils.createByteBuffer(i * j * 3);
      }
      if ((ai == null) || (ai.length < i * j * 3))
      {
        abyte0 = new byte[i * j * 3];
        ai = new int[i * j];
      }
      GL11.glPixelStorei(3333, 1);
      GL11.glPixelStorei(3317, 1);
      bytebuffer.clear();
      GL11.glReadPixels(0, 0, i, j, 6407, 5121, bytebuffer);
      bytebuffer.clear();
      String s = getSelectedServer().getServerAddress().replaceAll(":", "_");
      File file1 = new File(file, s + ".png");
      if (file1.exists())
      {
        file1.delete();
      }
      bytebuffer.get(abyte0);
      for (int k = 0; k < i; k++)
      {
        for (int l = 0; l < j; l++)
        {
          int i1 = k + (j - l - 1) * i;
          int j1 = abyte0[(i1 * 3 + 0)] & 0xFF;
          int k1 = abyte0[(i1 * 3 + 1)] & 0xFF;
          int l1 = abyte0[(i1 * 3 + 2)] & 0xFF;
          int i2 = 0xFF000000 | j1 << 16 | k1 << 8 | l1;
          ai[(k + l * i)] = i2;
        }

      }

      BufferedImage bufferedimage = new BufferedImage(i, j, 1);
      bufferedimage.setRGB(0, 0, i, j, ai, 0, i);
      BufferedImage bufferedimage1 = new BufferedImage(128, 72, 1);
      Graphics2D graphics2d = bufferedimage1.createGraphics();
      graphics2d.drawImage(bufferedimage, 0, 0, 128, 72, null);
      graphics2d.dispose();
      ImageIO.write(bufferedimage1, "png", file1);
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }

  public HashMap getButtonList()
  {
    return this.buttonList;
  }

  public static lq getInstance()
  {
    return instance;
  }

  public void setServerSpecificButtonsEnabled(boolean flag)
  {
    if (!this.buttonList.containsKey(EnumMultiplayerButton.CONNECT))
    {
      return;
    }

    ((ke)this.buttonList.get(EnumMultiplayerButton.CONNECT)).g = flag;
    ((ke)this.buttonList.get(EnumMultiplayerButton.EDIT)).g = flag;
    ((ke)this.buttonList.get(EnumMultiplayerButton.DELETE)).g = flag;
  }

  public void initConfig()
  {
    new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu").mkdirs();
    File file = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "server_list.dat");
    if (!file.exists())
    {
      saveServerList();
    }
    new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu").mkdirs();
    File file1 = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "settings.cfg");
    if (!file1.exists())
    {
      savePreferences();
    }
    loadPreferences();
  }

  private void loadPreferences()
  {
    try
    {
      File file = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "settings.cfg");
      if (file.exists())
      {
        BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
        String s = "";
        String s1;
        while ((s1 = bufferedreader.readLine()) != null)
        {
          String[] as = s1.split(":", 2);
          if ((as.length > 1) && (this.settings.containsKey(as[0])))
          {
            this.settings.put(as[0], as[1]);
          }
        }
        bufferedreader.close();
      }
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }

  private void savePreferences()
  {
    try
    {
      File file = new File(getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "settings.cfg");
      PrintWriter printwriter = new PrintWriter(new FileWriter(file));
      String s;
      for (Iterator iterator = this.settings.keySet().iterator(); iterator.hasNext(); printwriter.println(s + ":" + (String)this.settings.get(s)))
      {
        s = (String)iterator.next();
      }

      printwriter.close();
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }

  public HashMap getSettings()
  {
    return this.settings;
  }

  public HashMap getScreenshots()
  {
    return this.screenshots;
  }
}