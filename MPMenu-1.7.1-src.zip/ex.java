import java.util.List;
import net.minecraft.client.Minecraft;

public class ex extends da
{
  private String a;
  private String i;

  public ex(String s, String s1, Object[] aobj)
  {
    nh stringtranslate = nh.a();
    this.a = stringtranslate.a(s);
    if (aobj != null)
    {
      this.i = stringtranslate.a(s1, aobj);
    }
    else
      this.i = stringtranslate.a(s1);
  }

  public void a()
  {
  }

  protected void a(char c, int i)
  {
  }

  public void b()
  {
    nh stringtranslate = nh.a();
    this.e.clear();
    this.e.add(new ke(1, this.c / 2 - 100, this.d / 4 + 120 + 12 - 24, "Reconnect"));
    this.e.add(new ke(0, this.c / 2 - 100, this.d / 4 + 120 + 12, "Back to Multiplayer menu"));
  }

  protected void a(ke guibutton)
  {
    if (guibutton.f == 0)
    {
      this.b.a(lq.getInstance());
    }
    if (guibutton.f == 1)
    {
      if (lq.getInstance().getSelectedServerId() == -1)
      {
        if ((lq.tempSelectedServer != null) && (!lq.tempSelectedServer.equals("")))
        {
          GuiMultiplayerServer guimultiplayerserver = new GuiMultiplayerServer();
          guimultiplayerserver.setServerAddress(lq.tempSelectedServer);
          lq.getInstance().connectToServer(guimultiplayerserver);
        }
        else {
          this.b.a(lq.getInstance());
        }
      }
      else
        lq.getInstance().connectToServer(lq.getInstance().getSelectedServer());
    }
  }

  public void a(int i, int j, float f)
  {
    i();
    a(this.g, this.a, this.c / 2, this.d / 2 - 50, 16777215);
    a(this.g, this.i, this.c / 2, this.d / 2 - 10, 16777215);
    super.a(i, j, f);
  }
}