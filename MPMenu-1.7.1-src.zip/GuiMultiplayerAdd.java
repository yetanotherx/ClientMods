import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiMultiplayerAdd extends da
{
  private lq parent;
  private ro textboxServerLocation;
  private ro textboxServerName;

  public GuiMultiplayerAdd(lq guimultiplayer)
  {
    this.parent = guimultiplayer;
  }

  public void a()
  {
    this.textboxServerLocation.b();
    this.textboxServerName.b();
  }

  public void b()
  {
    nh stringtranslate = nh.a();
    Keyboard.enableRepeatEvents(true);
    this.e.clear();
    this.e.add(new ke(0, this.c / 2 - 100, this.d / 4 + 96 + 12, "Add server"));
    this.e.add(new ke(1, this.c / 2 - 100, this.d / 4 + 120 + 12, stringtranslate.a("gui.cancel")));
    ((ke)this.e.get(0)).g = false;
    this.textboxServerName = new ro(this, this.g, this.c / 2 - 100, 60, 200, 20, "");
    this.textboxServerName.a(64);
    this.textboxServerName.a = true;
    this.textboxServerLocation = new ro(this, this.g, this.c / 2 - 100, 116, 200, 20, "");
    this.textboxServerLocation.a(64);
  }

  public void h()
  {
    Keyboard.enableRepeatEvents(false);
  }

  protected void a(ke guibutton)
  {
    if (!guibutton.g)
    {
      return;
    }
    if (guibutton.f == 0)
    {
      this.parent.createServer(this.textboxServerName.a(), this.textboxServerLocation.a());
    }
    this.b.a(this.parent);
  }

  protected void a(char c, int i)
  {
    if (this.textboxServerLocation.a)
    {
      this.textboxServerLocation.a(c, i);
    }
    else if (this.textboxServerName.a)
    {
      this.textboxServerName.a(c, i);
    }
    if (c == '\r')
    {
      a((ke)this.e.get(0));
    }
    ((ke)this.e.get(0)).g = (this.textboxServerLocation.a().length() > 0);
  }

  protected void a(int i, int j, int k)
  {
    super.a(i, j, k);
    this.textboxServerLocation.a(i, j, k);
    this.textboxServerName.a(i, j, k);
  }

  public void a(int i, int j, float f)
  {
    i();
    a(this.g, "Add a new server", this.c / 2, this.d / 4 - 60 + 20, 16777215);
    b(this.g, "Server name: ", this.c / 2 - 100, 47, 10526880);
    b(this.g, "Server address: ", this.c / 2 - 100, 104, 10526880);
    this.textboxServerLocation.c();
    this.textboxServerName.c();
    super.a(i, j, f);
  }
}