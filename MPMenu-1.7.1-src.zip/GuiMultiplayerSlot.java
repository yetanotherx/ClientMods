import java.io.File;
import java.util.ArrayList;
import org.lwjgl.opengl.GL11;

public class GuiMultiplayerSlot extends lg
{
  private final lq parent;
  private boolean hasRendered;

  public GuiMultiplayerSlot(lq guimultiplayer)
  {
    super(guimultiplayer.b, guimultiplayer.c, guimultiplayer.d, 32, guimultiplayer.d - 64, 36);
    this.hasRendered = false;
    this.parent = guimultiplayer;
  }

  protected int a()
  {
    return this.parent.getServerList().size();
  }

  protected void a(int i, boolean flag)
  {
    this.parent.selectServer(i);
    boolean flag1 = (this.parent.getSelectedServerId() >= 0) && (this.parent.getSelectedServerId() < a());
    this.parent.setServerSpecificButtonsEnabled(flag1);
    if ((flag) && (flag1))
    {
      this.parent.connectToServer(this.parent.getSelectedServer());
    }
  }

  protected boolean c_(int i)
  {
    return this.parent.getSelectedServerId() == i;
  }

  protected int b()
  {
    return this.parent.getServerList().size() * 36;
  }

  protected void c()
  {
    this.parent.i();
  }

  protected void a(int i, int j, int k, int l, nw tessellator)
  {
    String s = ((GuiMultiplayerServer)this.parent.getServerList().get(i)).getServerName();
    String s1 = ((GuiMultiplayerServer)this.parent.getServerList().get(i)).getServerAddress();
    String s2 = s1.replaceAll(":", "_") + ".png";
    s1 = s1.replaceAll("_", ":");
    if (s.equals(""))
    {
      s = s1.toString();
      s1 = "";
    }
    try
    {
      File file = new File(this.parent.getModLibPath(), "mods" + File.separator + "yetanotherx" + File.separator + "mpmenu" + File.separator + "screenshots" + File.separator + s2);
      if (file.exists())
      {
        GL11.glBindTexture(3553, this.parent.getTexture(file));
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        tessellator.b();
        tessellator.b(16777215);
        tessellator.a(j, k + l, 0.0D, 0.0D, 1.0D);
        tessellator.a(j + 48, k + l, 0.0D, 1.0D, 1.0D);
        tessellator.a(j + 48, k, 0.0D, 1.0D, 0.0D);
        tessellator.a(j, k, 0.0D, 0.0D, 0.0D);
        tessellator.a();
        this.parent.b(this.parent.g, s, j + 52, k + 1, 16777215);
        this.parent.b(this.parent.g, s1, j + 52, k + 12, 8421504);
      }
      else {
        this.parent.b(this.parent.g, s, j + 2, k + 1, 16777215);
        this.parent.b(this.parent.g, s1, j + 2, k + 12, 8421504);
      }
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
      this.parent.b(this.parent.g, s, j + 2, k + 1, 16777215);
      this.parent.b(this.parent.g, s1, j + 2, k + 12, 8421504);
    }
  }
}